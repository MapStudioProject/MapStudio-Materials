# MapStudio-Materials
A preset database for material preset .zips used by tools like Track Studio.

The preset format includes .json material information along with optional material animations and textures.

Feel free to make a PR for additional materials to be added or improved.

To install, put these in the Presets/Materials folder of the program.
